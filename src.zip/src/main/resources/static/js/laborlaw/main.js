/**
 * 
 */
function getLaborlaw() {	
         $.ajax({ 
             url: "/laborlaw", 
             contentType : 'application/json',
             data:{
                 "async":true                 
             },
             success: function(data){
            	
                 $("#mainContainer").html(data);                 
             },
             error : function() {
                 toastr.error("error!");
             }
         });
    }
$("#submitLaborlaw").click(function() {
        $.ajax({ 
             url: "/laborlaw", 
             type: 'POST',
             data:$('#userForm').serialize(),
             success: function(data){
                 if (data.success) {
                	 alert("save successful");
                	 getLaborlaw();
                 } else {
                     toastr.error(data.message);
                 }

             },
             error : function() {
                 toastr.error("error!");
             }
         });
    });